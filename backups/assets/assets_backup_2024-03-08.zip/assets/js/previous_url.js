// getting the current url of a page
document.getElementById('previous_url').value = window.location.href;
document.getElementsByName('previous_url').value = window.location.href;
